#include <stdio.h>
#include<stdlib.h>
#include<string.h>
void payments();
int hash(const char key[7],int maxAddress)
{
    int sum=1,index=0;
    int ascii=0;
    for(index=0;index<6;index++)
    {
        ascii=key[index];
        sum=(sum*100*ascii)%7867;
    }
    return sum%maxAddress;
}

void hashString(const char *str) {
    int result=hash(str, 1000);
    FILE *file=fopen("payment.txt","a");
    if (file)
    {
        fprintf(file,"%d\n",result);
        fclose(file);
    }
}

int main()
{
    payments();
    printf("Hash successfully written to payment.txt\n");
    return 0;
}

 void payments()
{
    int option;
    char upiId[50], cardNumber[20], cvv[4], acc_number[20];

    printf("Choose your payment method:\n");
    printf("1. UPI\n");
    printf("2. Credit card\n");
    printf("3. Debit card\n");
    printf("4. Net Banking\n");
    scanf("%d", &option);

    switch (option)
    {
        case 1:
            printf("Enter UPI ID:\n");
            scanf("%s", upiId);
            hashString(upiId);// Hash the entered UPI ID and write it to the payment.txt file
            break;
        case 2:
            printf("Enter card number and CVV:\n");
            scanf("%s %s", cardNumber, cvv);
            hashString(cardNumber);
            hashString(cvv);// Hash the entered card number and CVV and write it to the payment.txt file
            break;
        case 3:
            printf("Enter card number and CVV:\n");
            scanf("%s %s", cardNumber, cvv);
            hashString(cardNumber);
            hashString(cvv);// Hash the entered card number and CVV and write it to the payment.txt file
            break;
        case 4:
            printf("Enter account number");
            scanf("%s", acc_number);
            hashString(acc_number);// Handle Net Banking transactions
            break;
        default:
            printf("Invalid option selected. Please try again.\n");
            break;
    }
}
