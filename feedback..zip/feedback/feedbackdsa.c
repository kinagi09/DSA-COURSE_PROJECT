#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void provideFeedback(int userId, char feedback[100]) {
    FILE *file=fopen("feedback.txt","a");
    if (file == NULL) {
        printf("Error opening the file.\n");
        return;
    }
    fprintf(file,"User ID:%d\nFeedback:%s\n\n",userId,feedback);
    fclose(file);
}

void clearFeedback()
{
    FILE *file=fopen("feedback.txt","w");
    if(file==NULL)
    {
        printf("Error opening the file.\n");
        return;
    }
    fclose(file);
}

int main()
{
    int userId;
    char feedback[100];
    // Get user ID from the user
    printf("Enter User ID: ");
    scanf("%d",&userId);
    // Clear the input buffer
    while (getchar() != '\n');
    // Get feedback from the user (allowing spaces)
    printf("Enter feedback: ");
    fgets(feedback,sizeof(feedback),stdin);
    // Remove the newline character from the feedback
    feedback[strcspn(feedback, "\n")] = '\0';
    // Call provideFeedback function
    provideFeedback(userId, feedback);
    // Option to clear feedback
    char clearOption;
    printf("Do you want to clear feedback? (y/n): ");
    scanf("%c",&clearOption);

    if(clearOption=='y'||clearOption=='Y')
    {
        clearFeedback();
        printf("Feedback cleared.\n");
    }

    return 0;
}

